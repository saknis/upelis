
cd "/mnt/app/upelis/"

