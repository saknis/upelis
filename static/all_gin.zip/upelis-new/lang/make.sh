
cd "/win1/app/upelis/upelis-new/lang/by_BY/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/en_US/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/lt_LT/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/ru_RU/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/de_DE/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/it_IT/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/lv_LV/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/ua_UA/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/pl_PL/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po
cd "/win1/app/upelis/upelis-new/lang/de_DE/LC_MESSAGES/"
python /win1/Python27/Tools/i18n/msgfmt.py upelis.po

