"""
Postmarkup
Author: Will McGugan (http://www.willmcgugan.com)

BBCode rendering engine

http://code.google.com/p/postmarkup/

"""

__version__ = "1.2.0"

from parser import *
